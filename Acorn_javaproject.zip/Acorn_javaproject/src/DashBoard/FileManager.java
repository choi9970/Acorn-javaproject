package DashBoard;

import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class FileManager {
    private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    // 파일에서 게시글 불러오기
    public static List<Board> loadData2(String fileName) {
        List<Board> boardList = new ArrayList<>();
        
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");         //CSV는 "," 기준으로 데이터 구분

                if (parts.length < 5) {            //데이터가 5개 미만이면 스킵                     
                    System.out.println("잘못된 데이터 형식: " + line);
                    continue; 
                }
                
                
                try {
                    int id = Integer.parseInt(parts[0].trim());
                    String title = parts[1].trim();
                    String content = parts[2].trim();
                    String writer = parts[3].trim();
                    Date regDate = sdf.parse(parts[4].trim());

                    Board board = new Board(id, title, content, writer, regDate);   
                    boardList.add(board);         //파일 데이터를 리스트로 
                } catch (NumberFormatException | ParseException e) {
                    System.out.println("데이터 파싱 오류: " + line);
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("파일을 찾을 수 없습니다: " + fileName);
        } catch (IOException e) {
            System.out.println("파일 읽기 오류: " + e.getMessage());
        }

        return boardList;
    }

    // 게시글을 CSV 파일로 저장
    public static void saveData(String fileName, List<Board> boardList) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(fileName))) {
            for (Board board : boardList) {
                bw.write(board.toCSV());       //CSV형식으로 받아 버퍼에 기록
                bw.newLine();
            }
            System.out.println("데이터 저장 완료: " + fileName);
        } catch (IOException e) {
            System.out.println("파일 저장 오류: " + e.getMessage());
        }
    }
}